import { createApp } from "vue";
import TinOnlinecv from "./screens/TinOnlinecv.vue";


createApp(TinOnlinecv).mount("#app");
