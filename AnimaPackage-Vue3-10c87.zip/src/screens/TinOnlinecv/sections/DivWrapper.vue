<template>
  <div class="div-wrapper">
    <div class="text-wrapper-26">Visual Studio (2017,19,22)</div>
    <div class="text-wrapper-27">VS Code</div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "DivWrapper",
});
</script>

<style>
.div-wrapper {
  height: 30px;
  left: 1156px;
  position: absolute;
  top: 3738px;
  width: 477px;
}

.div-wrapper .text-wrapper-26 {
  color: #000000;
  font-family: "Articulat CF-Light", Helvetica;
  font-size: 20px;
  font-weight: 300;
  left: 0;
  letter-spacing: 0;
  line-height: 30px;
  position: absolute;
  top: 0;
  width: 287px;
}

.div-wrapper .text-wrapper-27 {
  color: #000000;
  font-family: "Articulat CF-Light", Helvetica;
  font-size: 20px;
  font-weight: 300;
  left: 284px;
  letter-spacing: 0;
  line-height: 30px;
  position: absolute;
  top: 0;
  width: 193px;
}
</style>